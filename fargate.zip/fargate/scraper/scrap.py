from time import sleep
from parsel import Selector
from selenium import webdriver
from selenium.webdriver.chrome.webdriver import WebDriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities

import dynamodb



options = webdriver.ChromeOptions()
options.add_argument('--user-agent = Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/96.0.4664.55 Safari/537.36')
options.add_argument('--headless')
options.add_argument('window-size=1920x1080')
options.add_argument('disable-gpu')
options.add_argument('start-maximized')
options.add_argument('disable-infobars')
options.add_argument('--disable-extensions')
options.add_experimental_option('excludeSwitches', ['enable-automation'])
options.add_experimental_option('useAutomationExtension', False)
options.add_argument('--disable-blink-features=AutomationControlled')
chrome = DesiredCapabilities.CHROME

driver = webdriver.Remote(command_executor="http://15.164.226.76:4444", desired_capabilities=chrome, options=options)

# driver: WebDriver = webdriver.Chrome(service=s)

# sleep(1)
result = []
task_id_list =[]
index = 0
length_total = dynamodb.get_count_item("ongoing")
print("There are ",length_total, "tasks")
for index in range(4):
    ongoing_task = dynamodb.get_an_item("ongoing")
    # print(ongoing_task)
    if len(ongoing_task) == 1:
        # print(ongoing_task, len(ongoing_task))
        task_id = [task["task_id"] for task in ongoing_task][0]
        job_id = [job["job_id"] for job in ongoing_task][0]
        xpath_link = [xpath_link["xpath_link"] for xpath_link in ongoing_task][0]
        rule_data = [rule_data["rule_data"] for rule_data in ongoing_task][0]
        # print(rule_data)
        if 'javascript' not in xpath_link:
            driver.get(xpath_link)
            sleep(1)
            selector2 = Selector(driver.page_source)
            # extract_full_xpath = js['data'][0]['item'][0]['click_data'][0]['item'][0]['select_info']['xpathFull']
            title = selector2.xpath(f'{rule_data}/text()').get()
            # result.append({'title': title})
            dynamodb.update_item(task_id, job_id, "completed", xpath_link, rule_data)
            print(task_id, "HAS COMPLETED")
            dynamodb.input_item(job_id, task_id, title, xpath_link)
            driver.quit()
        else:
            print("it is error found")
            dynamodb.update_item(task_id, job_id, "completed", xpath_link, rule_data)
            driver.quit()

    else:
        print("all tasks have been completed")

